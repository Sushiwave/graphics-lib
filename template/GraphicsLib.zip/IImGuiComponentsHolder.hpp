#pragma once





class IImGuiComponentsHolder
{
public:
	virtual void drawImGuiComponents() = 0;
};