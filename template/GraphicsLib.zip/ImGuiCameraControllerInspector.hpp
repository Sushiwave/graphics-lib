#pragma once
#include <GraphicsLib.hpp>
#include "CameraController.hpp"




namespace ImGui
{
	void CameraControllerInspector(CameraController& cameraController, cg::Camera& camera);
}
