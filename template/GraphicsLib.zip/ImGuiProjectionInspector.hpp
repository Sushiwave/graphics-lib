#pragma once
#include <GraphicsLib.hpp>





namespace ImGui
{
	void ProjectionInspector(cg::Projection& projection);
}
