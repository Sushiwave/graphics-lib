#pragma once
#include <GraphicsLib.hpp>





namespace ImGui
{
	void TransformInspector(cg::Transform& transform);
}