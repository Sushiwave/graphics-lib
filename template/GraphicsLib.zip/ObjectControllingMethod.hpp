#pragma once





enum class ObjectControllingMethod
{
	none,
	lookAt,
	freeLookWASD,
};