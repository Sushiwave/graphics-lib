#include "RenderPipelineWithImGuiComponents.hpp"





RenderPipelineWithImGuiComponents::RenderPipelineWithImGuiComponents(const std::string& name) noexcept
	: RenderPipeline(name)
{
}
