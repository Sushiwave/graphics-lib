#include "ShapeWithImGuiComponents.hpp"





ShapeWithImGuiComponents::ShapeWithImGuiComponents(const cpp::Vector3D<float>& size)
	: Shape(size)
{
}
